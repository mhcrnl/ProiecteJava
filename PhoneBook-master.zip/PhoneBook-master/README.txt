///////////////////////////
JAVA PhoneBook!
//////////////////////////


repositories 안에 README.txt 를 넣으면
소스트리 맨 아래에 이렇게 txt 내용이 뜬다!

http://ejungdo.blog.me/50175192803
여기서 처음 이 프로그램에 대한 정보를 올렸다.

SQL_CODE.txt는 이 프로그램을 실행하기 위한 정보가 들어 있고 꼭 필요하다.


-------------------------------
Update README files.