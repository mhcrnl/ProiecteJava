public interface MAIN_MENU {
	int INPUT = 1, SEARCH = 2, DELETE = 3, LIST = 4, EXIT = 5;
}

enum MainMenu {
	I, S, D, L, E, M;
}

interface INPUT_MENU {
	int NORMAL = 1, UNIV = 2, COMPANY = 3;
}