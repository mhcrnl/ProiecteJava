# Phonebook
In this program name, surname and address of a person will be stored with maximum three phone
numbers. Every phone number is unique with its type. User can store name, surname and address of the person.

#Features
1. Ability to search person and phone number
2. Ability to create new person and new phone numbers. Phone numbers can be created only for 
the already created people.
3. Ability to update people and phone numbers.
4. Ability to delete person (when a person deleted all phone numbers belonging to that person also
should be deleted) and phone number.
5. Ability to list all records on the program and phone numbers of a selected person.
