package phone;

public class Main {

	public static void main(String[] args) {
		PhoneBook phoneBook = new PhoneBook();
		phoneBook.manipulate();
	}
}
