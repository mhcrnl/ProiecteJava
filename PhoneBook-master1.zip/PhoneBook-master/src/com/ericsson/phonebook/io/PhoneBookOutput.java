package com.ericsson.phonebook.io;

public interface PhoneBookOutput {

	public void doOutput();
}
