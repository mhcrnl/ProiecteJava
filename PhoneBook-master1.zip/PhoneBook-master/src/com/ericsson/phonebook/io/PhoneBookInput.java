package com.ericsson.phonebook.io;

public interface PhoneBookInput {

	public String readName();

	public String readPhoneNum();

}
